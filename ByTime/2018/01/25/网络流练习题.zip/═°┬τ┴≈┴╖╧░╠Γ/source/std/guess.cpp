//#line 7 "SpecialCells.cpp"
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <climits>
#include <algorithm>
#include <vector>
#include <string>
#include <iostream>
#include <map>
#include <set>
#include <queue>
#include <utility>
#include <ctime>
#include <sstream>
using namespace std;
#define pair(x, y) make_pair(x, y)
#define runtime() ((double)clock() / CLOCKS_PER_SEC)
using std::max;
using std::min;
using std::lower_bound;
using std::upper_bound;

typedef long long ll;

#define M 2000000
#define N 2000
struct edge {
	int next, node, w, c;
} e[M + 1];
int head[N + 1], tot;

inline void addedge(int a, int b, int w, int c) {
	e[++tot].next = head[a];
	head[a] = tot, e[tot].node = b, e[tot].w = w, e[tot].c = c;
	e[++tot].next = head[b];
	head[b] = tot, e[tot].node = a, e[tot].w = 0, e[tot].c = -c;
}

int d[N + 1], q[N + 1], f[N + 1], S, T;
bool inq[N + 1];

inline int inc(int &x) {
	return x = x + 1 == N ? 0 : x + 1;
}

bool SPFA() {
	int h = 0, t = 0;
	for (int i = S; i <= T; ++i) d[i] = INT_MAX;
	d[S] = 0, inq[S] = true, q[inc(t)] = S;
	while (h != t) {
		int cur = q[inc(h)];
		inq[cur] = false;
		for (int i = head[cur]; i; i = e[i].next) {
			if (!e[i].w) continue;
			int node = e[i].node;
			if (d[node] > d[cur] + e[i].c) {
				d[node] = d[cur] + e[i].c;
				f[node] = i;
				if (!inq[node])
					q[inc(t)] = node, inq[node] = true;
			}
		}
	}
	return d[T] != INT_MAX;
}

pair <int, int> minCost() {
	int ret = 0, flow = 0;
	while (SPFA()) {
		int w = INT_MAX;
		for (int i = T; i != S; i = e[f[i] ^ 1].node)
			w = min(w, e[f[i]].w);
		for (int i = T; i != S; i = e[f[i] ^ 1].node)
			e[f[i]].w -= w, e[f[i] ^ 1].w += w;
		flow += w, ret += d[T] * w;
	}
	return pair(ret, flow);
}

int X[N + 1], Y[N + 1];
map <int, int> xs, ys;
set <pair <int, int> > v;

class SpecialCells
{
public:
	int guess(vector <int> x, vector <int> y)
	{
		int n = x.size(), xcnt = 0, ycnt = 0;
		xs.clear(), ys.clear();
		map <int, int> :: iterator it;
		S = 0;
		for (int i = 0; i < n; ++i) X[i + 1] = x[i];
		for (int i = 0; i < n; ++i) Y[i + 1] = y[i];
		sort(X + 1, X + n + 1);
		sort(Y + 1, Y + n + 1);
		for (int i = 1, j; i <= n; i = j) {
			for (j = i + 1; j <= n && X[i] == X[j]; ++j) ;
			xs[X[i]] = ++xcnt;
		}
		for (int i = 1, j; i <= n; i = j) {
			for (j = i + 1; j <= n && Y[i] == Y[j]; ++j) ;
			ys[Y[i]] = ++ycnt;
		}
		T = xcnt + ycnt + 1;
		for (int i = S; i <= T; ++i) head[i] = 0;
		tot = 1;
		for (int i = 1, j; i <= n; i = j) {
			for (j = i + 1; j <= n && X[i] == X[j]; ++j) ;
			addedge(S, xs[X[i]], j - i, 0);
		}
		for (int i = 1, j; i <= n; i = j) {
			for (j = i + 1; j <= n && Y[i] == Y[j]; ++j) ;
			addedge(xcnt + ys[Y[i]], T, j - i, 0);
		}
		v.clear();
		for (int i = 0; i < n; ++i) {
			addedge(xs[x[i]], xcnt + ys[y[i]], 1, 1);
			v.insert(pair(x[i], y[i]));
		}
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= n; ++j) {
				int x = X[i], y = Y[j];
				if (v.find(pair(x, y)) != v.end()) continue;
				addedge(xs[x], xcnt + ys[y], 1, 0);
				v.insert(pair(x, y));
			}
		
		pair <int, int> res = minCost();
		return res.first;
	}
};

// BEGIN CUT HERE
int main()
{
	freopen("guess.in", "r", stdin);
	freopen("guess.out", "w", stdout);
	
	SpecialCells sol;
	
	int n;
	vector <int> a, b;
	cin >> n;
	for (int i = 1, x, y; i <= n; ++i) {
		cin >> x >> y;
		a.push_back(x), b.push_back(y);
	}
	int ans = sol.guess(a, b);
	cout << ans << endl;
	
	return 0;
}
