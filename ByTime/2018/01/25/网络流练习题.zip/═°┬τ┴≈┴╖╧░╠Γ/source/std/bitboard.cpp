// bitboard
#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;

#define NODE 100000
#define EDGE 1000000
#define INFI 123456789
struct edge {
	int next, node, w;
} e[EDGE << 1 | 1];
int head[NODE + 1], tot = 1;

inline void addedge(int a, int b, int w) {
	e[++tot].next = head[a];
	head[a] = tot, e[tot].node = b, e[tot].w = w;
	e[++tot].next = head[b];
	head[b] = tot, e[tot].node = a, e[tot].w = 0;
}

int S, T, d[NODE + 1], q[NODE + 1];

bool bfs() {
	int h = 0, t = 0;
	for (int i = S; i <= T; ++i)
		d[i] = 0;
	q[t++] = S, d[S] = 1;
	while (h < t) {
		int cur = q[h++];
		for (int i = head[cur]; i; i = e[i].next) {
			if (!e[i].w) continue;
			int node = e[i].node;
			if (d[node]) continue;
			d[node] = d[cur] + 1;
			q[t++] = node;
		}
	}
	return d[T] != 0;
}

int dfs(int x, int inflow) {
	if (x == T) return inflow;
	int ret = inflow, flow;
	for (int i = head[x]; i; i = e[i].next) {
		if (!e[i].w) continue;
		int node = e[i].node;
		if (d[node] != d[x] + 1) continue;
		flow = dfs(node, min(e[i].w, ret));
		if (!flow) continue;
		e[i].w -= flow, e[i ^ 1].w += flow, ret -= flow;
		if (!ret) break;
	}
	if (ret == inflow) d[x] = -1;
	return inflow - ret;
}

int maxFlow() {
	int ret = 0;
	while (bfs())
		ret += dfs(S, INFI);
	return ret;
}

#define N 300
int n, m, t[N + 1], p[N + 1], w[N + 1][N + 1];

inline int node(int x, int y) {
	return x * ((1 << m) + 1) + y + 1;
}

int main(int argc, char *argv[]) {
	freopen("bitboard.in", "r", stdin);
	freopen("bitboard.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	for (int i = 0; i < (1 << n); ++i)
		scanf("%d", t + i);
	for (int i = 0; i < (1 << n); ++i)
		scanf("%d", p + i);
	for (int i = 0; i < (1 << n); ++i)
		for (int j = 0; j < (1 << m); ++j)
			scanf("%d", &w[i][j]);
	
	int ans = 3000 * (1 << n);
	S = 0, T = (1 << n) * ((1 << m) + 1) + 1;
	for (int i = 0; i < (1 << n); ++i) {
		int cnt = __builtin_popcount(i);
		addedge(S, node(i, 0), INFI);
		for (int j = 0; j < (1 << m); ++j) {
			int val = (cnt & 1) ? w[i][(1 << m) - j - 1] : w[i][j];
			addedge(node(i, j), node(i, j + 1), 3000 - val);
		}
		addedge(node(i, (1 << m)), T, INFI);
		if (cnt & 1) {
			for (int j = 0; j < n; ++j) {
				int x = i ^ (1 << j);
				addedge(node(i, (1 << m) - t[i]), node(x, t[x]), p[i] ^ p[x]);
				ans += p[i] ^ p[x];
			}
		}
	}
	
	ans -= maxFlow();
	cout << ans << endl;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
