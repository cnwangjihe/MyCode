// paint
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <climits>
#include <algorithm>
#include <vector>
#include <string>
#include <iostream>
#include <map>
#include <queue>
#include <utility>
#include <ctime>
#include <sstream>
using namespace std;
#define pair(x, y) make_pair(x, y)
#define runtime() ((double)clock() / CLOCKS_PER_SEC)

typedef long long ll;

namespace Solution {
	#define NODE 300
	#define EDGE 2000
	#define INFI 123456789
	struct edge {
		int next, node, w, c;
	} e[EDGE << 1 | 1];
	int head[NODE + 1], tot;

	inline void addedge(int a, int b, int w, int c) {
		e[++tot].next = head[a];
		head[a] = tot, e[tot].node = b, e[tot].w = w, e[tot].c = c;
		e[++tot].next = head[b];
		head[b] = tot, e[tot].node = a, e[tot].w = 0, e[tot].c = -c;
	}

	int S, T, d[NODE + 1], from[NODE + 1], q[NODE + 1];
	bool inq[NODE + 1];

	inline int inc(int &x) {
		return x = x + 1 == NODE ? 0 : x + 1;
	}

	bool SPFA() {
		int h = 0, t = 0;
		for (int i = S; i <= T; ++i) d[i] = INT_MAX;
		d[S] = 0, inq[S] = true, q[inc(t)] = S;
		while (h != t) {
			int cur = q[inc(h)];
			inq[cur] = false;
			for (int i = head[cur]; i; i = e[i].next) {
				if (!e[i].w) continue;
				int node = e[i].node;
				if (d[node] > d[cur] + e[i].c) {
					d[node] = d[cur] + e[i].c;
					from[node] = i;
					if (!inq[node])
						inq[node] = true, q[inc(t)] = node;
				}
			}
		}
		return d[T] != INT_MAX;
	}

	int costFlow() {
		int ret = 0;
		while (SPFA()) {
			int w = INT_MAX;
			for (int i = T; i != S; i = e[from[i] ^ 1].node)
				w = min(w, e[from[i]].w);
			for (int i = T; i != S; i = e[from[i] ^ 1].node)
				e[from[i]].w -= w, e[from[i] ^ 1].w += w;
			ret += d[T] * w;
		}
		return ret;
	}

	#define N 50
	vector <int> son[N + 1];
	int n, f[N + 1][N + 1], w[N + 1], m;
	bool ok;

	void dfs(int x) {
		if (son[x].size() == 0) {
			f[x][1] = w[1] + w[2];
			for (int i = 2; i <= m; ++i) f[x][i] = w[i] + w[1];
			return ;
		}
		if (son[x].size() + 1 > m) {
			ok = false;
			return ;
		}
		for (int i = 0; i < son[x].size(); ++i)
			dfs(son[x][i]);
		for (int c = 1; c <= m; ++c) {
			memset(head, 0, sizeof head);
			tot = 1, S = 0, T = n + m + 1;
			for (int i = 0; i < son[x].size(); ++i)
				addedge(S, son[x][i], 1, 0);
			for (int i = 1; i <= m; ++i)
				if (i != c) addedge(n + i, T, 1, 0);
			for (int i = 0; i < son[x].size(); ++i)
				for (int j = 1; j <= m; ++j)
					addedge(son[x][i], n + j, 1, f[son[x][i]][j]);
			if (c == 1) f[x][c] = w[1] + w[2];
			else f[x][c] = w[c] + w[1];
			f[x][c] += costFlow();
		}
	}

	class GoodCompanyDivOne {
	public:
		int minimumCost(vector <int> fa, vector <int> training) {
			n = fa.size(), m = training.size();
			for (int i = 1; i <= m; ++i) w[i] = training[i - 1];
			sort(w + 1, w + m + 1);
			for (int i = 1; i <= n; ++i) son[i].clear();
			for (int i = 1; i < n; ++i)
				son[fa[i] + 1].push_back(i + 1);
			ok = true, dfs(1);
			int ans = INT_MAX;
			for (int i = 1; i <= m; ++i) ans = min(ans, f[1][i]);
			if (ok) return ans;
			return -1;
		}
	} Main;
}

int n, m;
vector <int> fa, w;

int main() {
	freopen("paint.in", "r", stdin);
	freopen("paint.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	fa.push_back(-1);
	for (int i = 1, x; i < n; ++i) {
		scanf("%d", &x);
		fa.push_back(x);
	}
	for (int i = 1, x; i <= m; ++i) {
		scanf("%d", &x);
		w.push_back(x);
	}
	
	int ans = Solution::Main.minimumCost(fa, w);
	printf("%d\n", ans);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
