#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>

using namespace std;

int main()
{
	freopen("2369.in","r",stdin);
	freopen("2369.out","w",stdout);
	printf("-1\n");
	return 0;
}
