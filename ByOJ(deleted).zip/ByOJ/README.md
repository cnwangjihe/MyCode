## Divide By OnlineJudge ##

#### Attention ####

This folder will be update *ONCE A WEEK*.

>P*.cpp    -- https://www.luogu.org/ 
>
>*.cpp     -- http://smoj.nhedu.net/ 
>
>POJ*.cpp  -- http://poj.org/
>
>UOJ*.cpp  -- http://uoj.ac/
>
>CP*.cpp   -- https://cp.thusaac.org/
>
>LOJ*.cpp  -- https://loj.ac/
>
>CF*.cpp   -- http://codeforces.com/
>
>JOY*.cpp  -- http://www.joyoi.cn/
>
>HH*.cpp   -- http://hihocoder.com/
